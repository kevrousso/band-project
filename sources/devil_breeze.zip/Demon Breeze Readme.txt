DEVIL BREEZE..Was designed based on the variations and similarities of AVANT GARDE Typeface 
(created in the era of the 60s by Herb Lubalin and Tom Carnese).

~~~~~~~~~~~~
Thank you for downloading "DEMON BREEZE Font"Fontsfor Windows, I hope you enjoy using it. 


Install
~~~~~~~
1. UnZip, install into C:\windows\fonts.

Uninstall
~~~~~~~~~
Delete the Startup\Settings\Control Panel\Fonts\(highlight font to be deleted)File\Delete.

Created By
~~~~~~~~~~
Date:9/30/2010
Filename: Demon Breeze.zip 
Title: "Demon Breeze"
Category: SansSeirif
Archive: Fonts



Suggestions or comments sent to WesleyPastrana : wpastrana11@gmail.com
ENJOY!!!


